console.log("Sayt yuklandi!");
